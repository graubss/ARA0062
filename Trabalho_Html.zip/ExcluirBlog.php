<?php

include_once "../servico/bd.php";

$id=$_GET["id"];

$sql = "delete from blog where id='$id' ";
$bd = new bd();
$contador = $bd->exec($sql);

echo "<h1>foi excluído $contador registro</h1>";

?>

<a href="ConsultaBlog.php">Voltar</a>